from flask import Flask, render_template, request, redirect, url_for, session, flash
import mysql.connector
from functools import wraps

app = Flask(__name__)
app.secret_key = 'your_secret_key'

# Funcion acceso a base de datos
def get_db_connection():
    connection = mysql.connector.connect(
        host='127.0.0.1',
        user='root',  
        password='', 
        database='kelxstudiosgst'
    )
    return connection

#Funcion acceso administrador
def admin_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'id_usuario' not in session or session.get('rol') != 'administrador':
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated_function

# Funcion inicio de session 
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        correo_electronico = request.form['correo_electronico']
        contrasena = request.form['contrasena']
        
        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)

        cursor.execute("SELECT id_usuario, nombre, apellido, correo_electronico, contrasena, rol FROM usuarios WHERE correo_electronico = %s", (correo_electronico,))
        usuario = cursor.fetchone()

        cursor.close()
        conn.close()

        if usuario and usuario['contrasena'] == contrasena:
            session['id_usuario'] = usuario['id_usuario']
            session['nombre'] = usuario['nombre']
            session['apellido'] = usuario['apellido']
            session['correo_electronico'] = usuario['correo_electronico']
            session['rol'] = usuario['rol']
            return redirect(url_for('usuarios'))
        else:
            return redirect(url_for('login'))

    return render_template('login.html')

# Funcion printar usuarios
@app.route('/usuarios')
@admin_required #Verifica la funcion de administrador
def usuarios():
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute("SELECT id_usuario, nombre, apellido, correo_electronico, rol FROM usuarios")
    usuarios = cursor.fetchall()
    cursor.close()
    conn.close()

    return render_template('usuarios.html', usuarios=usuarios)

# Funcion para crear usuario
@app.route('/crear_usuario', methods=['GET', 'POST'])
@admin_required 
def crear_usuario():
    if request.method == 'POST':
        nombre = request.form['nombre']
        apellido = request.form['apellido']
        correo_electronico = request.form['correo_electronico']
        contrasena = request.form['contrasena']
        rol = request.form['rol']

        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("INSERT INTO usuarios (nombre, apellido, correo_electronico, contrasena, rol) VALUES (%s, %s, %s, %s, %s)", 
                       (nombre, apellido, correo_electronico, contrasena, rol))
        conn.commit()
        cursor.close()
        conn.close()
        return redirect(url_for('usuarios'))

    return render_template('crear_usuario.html')

# Funcion para editar usuario
@app.route('/editar_usuario/<int:id_usuario>', methods=['GET', 'POST'])
@admin_required 
def editar_usuario(id_usuario):
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute("SELECT id_usuario, nombre, apellido, correo_electronico, rol FROM usuarios WHERE id_usuario = %s", (id_usuario,))
    usuario = cursor.fetchone()

    if request.method == 'POST':
        nombre = request.form['nombre']
        apellido = request.form['apellido']
        correo_electronico = request.form['correo_electronico']
        contrasena = request.form['contrasena']
        rol = request.form['rol']

        cursor.execute("UPDATE usuarios SET nombre = %s, apellido = %s, correo_electronico = %s, contrasena = %s, rol = %s WHERE id_usuario = %s",
                       (nombre, apellido, correo_electronico, contrasena, rol, id_usuario))
        conn.commit()
        cursor.close()
        conn.close()
        return redirect(url_for('usuarios'))

    cursor.close()
    conn.close()
    return render_template('editar_usuario.html', usuario=usuario)

# Funcion para eliminar usuario
@app.route('/eliminar_usuario/<int:id_usuario>', methods=['POST'])
@admin_required 
def eliminar_usuario(id_usuario):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("DELETE FROM usuarios WHERE id_usuario = %s", (id_usuario,))
    conn.commit()
    cursor.close()
    conn.close()
    return redirect(url_for('usuarios'))

# Funcion printar pedidos
@app.route('/pedidos')
@admin_required 
def pedidos():
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute("SELECT * FROM pedidos")
    pedidos = cursor.fetchall()
    cursor.close()
    conn.close()
    return render_template('pedidos.html', pedidos=pedidos)

if __name__ == '__main__':
    app.run(debug=True)
