<?php
header("Content-Type: application/json");
include 'conexion.php'; 

try {
    
    if (isset($_GET['id_categoria'])) {
        $id_categoria = intval($_GET['id_categoria']); 

        // Consulta para obtener productos de una categoría específica
        $sql = "SELECT id_producto, nombre, descripcion, precio, cantidad_stock, imagen_url, id_categoria 
                FROM productos 
                WHERE id_categoria = ?";
        $stmt = $conn->prepare($sql); 
        $stmt->bind_param("i", $id_categoria);
        $stmt->execute();
        $result = $stmt->get_result();

        // Inicializamos un array para almacenar los productos
        $products = array();

        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $products[] = $row; 
            }
        }
        
        echo json_encode($products);

        $stmt->close(); 
    } else {
    
        echo json_encode(array("error" => "No se proporcionó el parámetro id_categoria."));
    }
} catch (Exception $e) {
    echo json_encode(array("error" => $e->getMessage()));
}

$conn->close();
?>
