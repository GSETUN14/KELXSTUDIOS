<?php
include 'conexion.php';  // Conexión a la base de datos

// Obtener los datos del pedido desde el cuerpo de la solicitud
$data = json_decode(file_get_contents("php://input"));

// Validar que los datos necesarios estén presentes
if(isset($data->id_usuario) && isset($data->total)) {
    $id_usuario = $data->id_usuario;
    $total = $data->total;

    // Prepara la consulta SQL para insertar el pedido en la base de datos
    $sql = "INSERT INTO pedidos (id_usuario, total, estado, metodo_pago, factura_url) 
            VALUES (?, ?, 'PROCESANDO', NULL, NULL)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("id", $id_usuario, $total);
    if ($stmt->execute()) {
        echo json_encode(["status" => "success", "message" => "Pedido guardado"]);
    } else {
        echo json_encode(["status" => "error", "message" => "Error al guardar el pedido"]);
    }

    $stmt->close();
} else {
    echo json_encode(["status" => "error", "message" => "Faltan datos"]);
}

$conn->close();
?>
