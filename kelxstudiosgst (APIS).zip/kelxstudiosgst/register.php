<?php
include 'conexion.php';

$name = $_POST['name'];
$lastName = $_POST['lastName'];
$email = $_POST['email'];
$phone = $_POST['phone'];
$password = $_POST['password'];

// Validar si el correo ya existe
$sql_check = "SELECT * FROM usuarios WHERE correo_electronico = ?";
$stmt_check = $conn->prepare($sql_check);
$stmt_check->bind_param("s", $email);
$stmt_check->execute();
$result_check = $stmt_check->get_result();

if ($result_check->num_rows > 0) {
    echo json_encode(["status" => "error", "message" => "El correo ya existe"]);
    exit();
}

// Insertar nuevo usuario
$sql_insert = "INSERT INTO usuarios (nombre, apellido, correo_electronico, telefono, contrasena) VALUES (?, ?, ?, ?, ?)";
$stmt = $conn->prepare($sql_insert);
$stmt->bind_param("sssss", $name, $lastName, $email, $phone, $password);

if ($stmt->execute()) {
    echo json_encode(["status" => "success", "message" => "Usuario registrado"]);
} else {
    echo json_encode(["status" => "error", "message" => "Error de registro"]);
}

$stmt->close();
$conn->close();
?>
