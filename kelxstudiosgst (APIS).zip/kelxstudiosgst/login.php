<?php
include 'conexion.php';  // Incluye la conexión a la base de datos

$correo = $_POST['correo'];  // Recibe el correo desde la app.
$contrasena = $_POST['contrasena']; // Recibe la contraseña desde la app.

// Consulta SQL para obtener el usuario que coincida con el correo y la contraseña
$sql = "SELECT id_usuario, nombre, rol FROM usuarios WHERE correo_electronico = ? AND contrasena = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ss", $correo, $contrasena); 
$stmt->execute();
$result = $stmt->get_result();


if ($result->num_rows > 0) {
 
    $usuario = $result->fetch_assoc();
    echo json_encode(["status" => "success", "data" => $usuario]);
} else {
    
    echo json_encode(["status" => "error", "message" => "Correo o contraseña incorrectos"]);
}

$stmt->close(); 
$conn->close(); 
?>
